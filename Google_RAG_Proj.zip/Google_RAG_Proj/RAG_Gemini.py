from vertexai.language_models import TextEmbeddingModel
from google.cloud import aiplatform
import vertexai
from vertexai.preview.generative_models import GenerativeModel, Part
import json

project = "carbon-atrium-426707-f9"
location = "us-central1"
sentence_file_path = "RAG_Req_Gen_chunks.json"
index_name="rag_vector_search_index_local"
f_output = "C:/Dharmesh/RAG_Projects/Google_RAG_Proj/Google_RAG_Proj/Data/RAG_Output.txt"

aiplatform.init(project=project,location=location)
vertexai.init()
model = GenerativeModel("gemini-pro")
rag_vector_search_index_local_ep = aiplatform.MatchingEngineIndexEndpoint(index_endpoint_name="5450565011908853760")


def generate_text_embeddings(sentences) -> list:
    model = TextEmbeddingModel.from_pretrained("textembedding-gecko@001")
    embeddings = model.get_embeddings(sentences)
    vectors = [embedding.values for embedding in embeddings]
    return vectors


def generate_context(ids, data):
    concatenated_names = ''
    for id in ids:
        for entry in data:
            if entry['id'] == id:
                concatenated_names += entry['sentence'] + "\n"
    return concatenated_names.strip()


def load_file(sentence_file_path):
    data = []
    with open(sentence_file_path, 'r') as f:
        for line in f:
            entry = json.loads(line)
            data.append(json.loads(line))
    return data

data=load_file(sentence_file_path)

query=["Can you Generate the software requirements for the FOTA implementation in automotive industry?"]
qry_emb=generate_text_embeddings(query)

response = rag_vector_search_index_local_ep.find_neighbors(
    deployed_index_id = index_name,
    queries = [qry_emb[0]],
    num_neighbors = 10
)

matching_ids = [neighbor.id for sublist in response for neighbor in sublist]

context = generate_context(matching_ids,data)
prompt=f"Based on the input specification, ```{context}``` {query} \
Generated detailed software requirements shall consist of following sections:  \
1. Functional requirements 2. Non-Functional requirements 3. memory related 4. Target ECU and Handler"

chat = model.start_chat(history=[])
response = chat.send_message(prompt)
#print(response.text)
with open(f_output, 'w') as file:
        file.write(response.text)