import os
from PyPDF2 import PdfReader
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.vectorstores import FAISS
from langchain.text_splitter import CharacterTextSplitter
from langchain.chains import RetrievalQA
from langchain.llms import OpenAI

# Set your OpenAI API key
os.environ["OPENAI_API_KEY"] = "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"

def extract_text_from_pdf(pdf_path):
    """Extracts text from a PDF file."""
    with open(pdf_path, 'rb') as file:
        pdf = PdfReader(file)
        text = ""
        for page in pdf.pages:
            text += page.extract_text()
    return text

def create_embeddings_and_vector_store(text):
    """Creates embeddings and stores them in a FAISS vector store."""
    text_splitter = CharacterTextSplitter(chunk_size=500, chunk_overlap=100)
    chunks = text_splitter.split_text(text)

    embeddings = OpenAIEmbeddings()
    vector_store = FAISS.from_texts(chunks, embeddings)
    return vector_store

def answer_question(vector_store, question):
    """Answers a question using RAG."""
    retriever = vector_store.as_retriever()
    qa_chain = RetrievalQA.from_chain_type(
        llm=OpenAI(temperature=0.1),
        chain_type="stuff",
        retriever=retriever,
    )
    answer = qa_chain.run(question)
    return answer

if __name__ == "__main__":
    # Replace with your PDF file path
    pdf_path = "C:/Dharmesh/RAG_Projects/GPT_RAG_Proj/GPT_RAG_Proj/Data/AUTOSAR_CP_RS_FirmwareOverTheAir.pdf"

    # Extract text from PDF
    text = extract_text_from_pdf(pdf_path)

    # Create embeddings and vector store
    vector_store = create_embeddings_and_vector_store(text)

    # Ask your question
    question = "can you write 20 software requirements from the input document. The form must be <The software shall>"

    # Get answer using RAG
    answer = answer_question(vector_store, question)

    print(f"Answer: {answer}")